package com.todo.list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListApplicationTests {

	@Test
	void contextLoads() {
	}

}
